package aopexample;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestA {

	public static void main(String[] args) {
		   Resource r=new ClassPathResource("aopContext.xml");  
			BeanFactory factory=new XmlBeanFactory(r);  
			A a1=factory.getBean("proxy",A.class);  
			a1.fun();  

	}

}
