package aopexample;

public class A {
   public void fun()
   {
	   System.out.println("A");
   }
}
