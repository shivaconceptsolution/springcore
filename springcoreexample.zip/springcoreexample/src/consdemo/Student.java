package consdemo;

public class Student {
   private int rno;
   private String sname;
   Student(int rno,String sname)
   {
	   this.rno=rno;
	   this.sname = sname;
   }
   public String toString()
   {
	 return "rno is " + rno +" name is "+sname;
   }
}
