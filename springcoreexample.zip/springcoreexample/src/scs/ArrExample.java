package scs;

import java.util.HashMap;

public class ArrExample {
  private int arr[]={1,2,3};
  private HashMap<String,String> map;
  

public int[] getArr() {
	return arr;
}

public void setArr(int[] arr) {
	this.arr = arr;
}

public HashMap<String, String> getMap() {
	return map;
}

public void setMap(HashMap<String, String> map) {
	this.map = map;
}
  
}
