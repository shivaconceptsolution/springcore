package scs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class ArrExample {
  private List arr;
  private Map<String,String> map;
  private Vector vect;
  private Set ast;
  
   public Set getAst() {
	return ast;
}
public void setAst(Set ast) {
	this.ast = ast;
}
public Vector getVect() {
	return vect;
}
public void setVect(Vector vect) {
	this.vect = vect;
}
public List getArr() {
	return arr;
	}
   public void setArr(List arr) {
	this.arr = arr;
}

public Map<String, String> getMap() {
	return map;
}

public void setMap(Map<String, String> map) {
	this.map = map;
}
  
}
