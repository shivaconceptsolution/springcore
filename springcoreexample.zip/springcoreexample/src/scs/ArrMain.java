package scs;

import java.util.HashMap;
import java.util.*;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class ArrMain {
	public static void main(String[] args) {
		ClassPathResource res = new ClassPathResource("applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		ArrExample obj =(ArrExample) factory.getBean("arr1");
		ArrExample obj11 =(ArrExample) factory.getBean("arr2");
		ArrayList arr2 =  (ArrayList)obj.getArr();
		for(Object arr3:arr2)
		{
			System.out.println(arr3);
		}
		Vector v =  (Vector)obj11.getVect();
		for(Object arr4:v)
		{
			System.out.println(arr4);
		}
		
		
		ArrExample obj1 =(ArrExample) factory.getBean("mp1");
		Map<String,String> hs= obj1.getMap();
		Set<Map.Entry<String,String>> st = hs.entrySet();
		for(Map.Entry<String,String> s:st)
		{
			System.out.println(s.getKey() + " , " + s.getValue());
		}
		ArrExample obj12 =(ArrExample) factory.getBean("arr3");
		HashSet h =  (HashSet)obj12.getAst();
		for(Object arr5:h)
		{
			System.out.println(arr5);
		}
		
		

	}
}
