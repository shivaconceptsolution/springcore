package scs;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class AddMain {
	public static void main(String[] args) {
		//ClassPathResource res = new ClassPathResource("applicationContext.xml");
		//BeanFactory factory = new XmlBeanFactory(res);
		
		ApplicationContext context =   
			    new ClassPathXmlApplicationContext("applicationContext.xml");  
		Add obj =(Add) context.getBean("add");
		obj.setA(230);
		obj.setB(120);
		System.out.println(obj.getA() + obj.getB());
		
		
		

	}
}
