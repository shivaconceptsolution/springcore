package autowireddemo;

public class B {
	B()
	{
		System.out.println("b is created");
	}  
	void print()
	{
			System.out.println("hello b");
	}  
}
