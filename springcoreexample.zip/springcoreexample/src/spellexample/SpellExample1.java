package spellexample;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class SpellExample1 {

	public static void main(String args[])
	{
		ExpressionParser parser = new SpelExpressionParser(); 
		Expression exp = parser.parseExpression("1+2");  
		//String message =(String);
		System.out.println(exp.getValue());
		
		
	}
}
