package spellexample;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

public class SqauareMain {
    public static void main(String args[])
    {
    	Square obj = new Square();
    	StandardEvaluationContext se = new StandardEvaluationContext(obj);
    	ExpressionParser parser = new SpelExpressionParser();  
    	parser.parseExpression("num").setValue(se,"5");
    	System.out.println(obj.sq());
    	
    	
    }
}
