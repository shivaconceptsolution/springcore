package spellexample;

public class Square {
  private int num;

public int getNum() {
	return num;
}

public void setNum(int num) {
	this.num = num;
}
  
int sq()
{
	return num*num;
}
}
